# Contribute

* Navigate to `examples/ng-cli`
* npm start
